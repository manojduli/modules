package com.cg.bank.dao;

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bank.bean.BankDetails;
import com.cg.bank.service.BankDetailsServiceImpl;



public class BankDetailsDao {
	public static ArrayList<BankDetails> arr = new ArrayList<BankDetails>();
	public void putDetails(BankDetails b1) throws SQLException{
		String URL= "JDBC:oracle:thin:@localhost:1521:XE";
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connect =DriverManager.getConnection(URL,"system","root");
		PreparedStatement stat= connect.prepareStatement("insert into Accountdetails values(?,?,?,?)");
				stat.setInt(1,b1.getAccountnumber());
				stat.setString(2,b1.getFirstName());
				stat.setString(3, b1.getLastName());
				stat.setInt(4, b1.getBalance());
				int result= stat.executeUpdate();
				System.out.println(result);
	}
	catch (ClassNotFoundException e) {
//		// TODO Auto-generated constructor stub
//		arr.add(b1);
//		System.out.println(arr);
//		
//		int c=b1.getAccountnumber();
//		System.out.println("Your bank account number is " +c);
		e.printStackTrace();
	}
	}
	public int showBalance(int accNo) throws SQLException {
//        try {
//        for(BankDetails b1 : arr){
//            if(b1.getAccountnumber()==accNo){
//                return b1;
//            }
//            else {
//            	throw new Exception("Enter the correct amount");
//            }
//            }
//        }
//        catch(Exception e) {
//            System.out.println(e);
//           
//        }
		String URL= "JDBC:oracle:thin:@localhost:1521:XE";
		int result= 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connect =DriverManager.getConnection(URL,"system","root");
			PreparedStatement stat= connect.prepareStatement("select balance from Accountdetails where accountnumber=?");
			stat.setInt(1,accNo);
			 ResultSet rs= stat.executeQuery();
			 while(rs.next()) {
				 result=rs.getInt("balance");
			 }
		}
		//	System.out.println(result);
			catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		return result;
     
    }
	public int depositBalance(int accNo,int amount) throws SQLException {
//		BankDetails b;
//		for(BankDetails b1:arr) {
//			if(b1.getAccountnumber()==accNo) {
//				return b1;
//			}
//			else {
//				System.out.println("Account number does'nt exisit");
//			}
//		}
		String URL= "JDBC:oracle:thin:@localhost:1521:XE";
		int result= 0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connect =DriverManager.getConnection(URL,"system","root");
			PreparedStatement stat= connect.prepareStatement("update Accountdetails set amountDeposit=? where accountnumber=?");

			ResultSet rs= stat.executeQuery();
			 while(rs.next()) {
				 result=rs.getInt("balance");
			 }
		}
		//	System.out.println(result);
			catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		return result;
		
	}
	public BankDetails withdrawBalance(int accNo) {
		 BankDetails b ;
	        for(BankDetails b1 : arr){
	            if(b1.getAccountnumber()==accNo){
	                return b1;
	                
	            }
	            else
	            {
	            	System.out.println("Account number does not exisit");
	            }
	        }
		
		return null;

}
	public BankDetails fundTransfer(int sourceaccNo1) {
		 BankDetails b ;
	        for(BankDetails b1 : arr){
	            if(b1.getAccountnumber()==sourceaccNo1){
	                return b1;
	                
	            }
	            else {
	            	System.out.println("Account number does not exisit");
	            }
	        }
		return null;
		
	}
	public BankDetails fundTransfer1(int destinationaccNo2) {
		 BankDetails b ;
	        for(BankDetails b1 : arr){
	            if(b1.getAccountnumber()==destinationaccNo2){
	                return b1;
	                
	            }
	            else {
	            	System.out.println("Account number does not exisit");
	            }
	        }
		return null;
		
	}
}
