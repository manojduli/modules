package com.cg.bank.bean;

import java.util.ArrayList;
import java.util.List;

public class BankDetails {
	private String FirstName;
	private String LastName;
	private int accountnumber;
	private int balance;
	private List<String> list = new ArrayList<String>();
	public String getFirstName() {
		return FirstName;
	}
	public List<String> getList() {
		return list;
	}
	public void setList(List<String> list) {
		this.list = list;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public int getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public BankDetails(String firstName, String lastName, int accountnumber, int balance) {
		super();
		FirstName = firstName;
		LastName = lastName;
		this.accountnumber = accountnumber;
		this.balance = balance;
	}
	public BankDetails() {
		// TODO Auto-generated constructor stub
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankDetails [FirstName=" + FirstName + ", LastName=" + LastName + ", accountnumber=" + accountnumber
				+ ", balance=" + balance + "]";
	}
}
