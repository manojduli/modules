package com.cg.bank.service;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bank.bean.BankDetails;
import com.cg.bank.dao.BankDetailsDao;


public class BankDetailsServiceImpl {

	public void newAccount() throws SQLException {
		System.out.println("enter the first name");
		Scanner sc1=new Scanner(System.in);
	    String FirstName=sc1.nextLine();
	    System.out.println("enter the last name");
	    Scanner sc2=new Scanner(System.in);
	    String LastName=sc2.nextLine();
	    
	    int accountNumber;
	  
	    accountNumber=(int) (Math.random()*100);
	    System.out.println("enter the amount");
	    Scanner sc4=new Scanner(System.in);
	     int balance =sc4.nextInt();
	    BankDetails  b1= new BankDetails(FirstName,LastName,accountNumber,balance);
		
	    BankDetailsDao dataLayerObj=new BankDetailsDao();
	    dataLayerObj.putDetails(b1) 	;
	    
	}
	public int showBalance() throws SQLException {

	BankDetailsDao dataLayerObj1=new BankDetailsDao();
	System.out.println("Enter account number");
		Scanner sc=new Scanner(System.in);
		int accNo=sc.nextInt();
int b = dataLayerObj1.showBalance(accNo);
	return b;
	
	
//		
	}
   public int depositBalance() throws SQLException {
	   
	   BankDetailsDao dataLayerObj2=new BankDetailsDao();
	   System.out.println("Enter the account number");
	   Scanner sc=new Scanner(System.in);
	   int accNo=sc.nextInt();
	   Scanner sc1=new Scanner(System.in);
	   int amount=sc1.nextInt();
	 int b1=  dataLayerObj2.depositBalance(accNo,amount);
	System.out.println("Enter the amount to deposit");
	Scanner sc7=new Scanner(System.in);
	int amountDeposit=sc7.nextInt();
	int c= b1+amountDeposit;
	   
	   return c;
   }
   public int withdrawBalance() {
	   BankDetailsDao dataLayerobj3=new BankDetailsDao();
	   System.out.println("Enter the account number");
	   Scanner sc=new Scanner(System.in);
	   int accNo=sc.nextInt();
	   BankDetails b2= dataLayerobj3.withdrawBalance(accNo);
	   System.out.println("Enter the withdrwal amount");
	   Scanner sc1=new Scanner(System.in);
	   int amount=sc1.nextInt();
	   int d=b2.getBalance()-amount;
	   b2.setBalance(d);
	   return d;
   }
   public int fundTransfer() {
	   BankDetailsDao dataLayerobj4 = new BankDetailsDao();
	   BankDetailsDao dataLayerObj5 = new BankDetailsDao();
	   System.out.println("Enter the source account number");
	   Scanner sc=new Scanner(System.in);
	   int sourceaccNo1=sc.nextInt();
	   System.out.println("Enter the destination account number");
	   Scanner sc1=new Scanner(System.in);
	   int destinationaccNo2=sc1.nextInt();
	   BankDetails b3 = dataLayerobj4.fundTransfer(sourceaccNo1);
	   System.out.println(b3);
	   BankDetails b4 = dataLayerObj5.fundTransfer1(destinationaccNo2);
	   System.out.println(b4);
	   System.out.println("Enter the amount to transfer");
	   Scanner sc7=new Scanner(System.in);
	   int amount =sc7.nextInt();
	   int e=b3.getBalance()-amount;
	   
	   b3.setBalance(e);
	   return e;
	   
   }
   public void PrintTransiet() {
	   
	   
   }

}
