package com.cg.bank.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bank.bean.BankDetails;
import com.cg.bank.service.BankDetailsServiceImpl;

public class BankDetailsUi {
	public void bankDetails() throws SQLException {
		BankDetailsServiceImpl obj1 = new BankDetailsServiceImpl();
		
		do {
			System.out.println("1:Create new account");
			System.out.println("2:Show balance");
			System.out.println("3:Deposit");
			System.out.println("4:withdarw");
			System.out.println("5:Fund Transfer");
			System.out.println("6:Print Tansiet");
			System.out.println("7:To exit");
			Scanner sc6= new Scanner(System.in);
			Scanner sc=new Scanner(System.in);
			int select =sc.nextInt();
			switch (select) {
			case 1:
				obj1.newAccount();
				break;
			case 2:
				
				System.out.println(obj1.showBalance());
				break;
			case 3:
			System.out.println(obj1.depositBalance());
			
				break;
			case 4:
			System.out.println("Total amount "+obj1.withdrawBalance()+"after withdrawal");
				break;
			case 5:
				System.out.println("Total amount "+obj1.fundTransfer()+"after the transction");
				break;
			case 6:
				
//			    Transaction

				break;
			case 7:
				System.exit(0);
				break;
			}
		}
		while(true);
	}
	public static void main(String args[]) throws SQLException {
		BankDetailsUi obj=new BankDetailsUi();
		obj.bankDetails();

	}
}
