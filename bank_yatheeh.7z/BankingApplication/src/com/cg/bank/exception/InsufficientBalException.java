package com.cg.bank.exception;

public class InsufficientBalException extends Exception {
	public    InsufficientBalException (){
	    super();
	}

}
